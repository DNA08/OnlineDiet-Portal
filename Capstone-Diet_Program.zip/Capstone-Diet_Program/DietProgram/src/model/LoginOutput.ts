export class LoginOutput{
    verified:boolean;
    userClass:string;
    userType:string;
}