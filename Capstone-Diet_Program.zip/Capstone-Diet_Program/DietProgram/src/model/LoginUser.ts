export class LoginUser{
    email:string;
    password:string;
    type:string;
    bmiGroup:string;
}