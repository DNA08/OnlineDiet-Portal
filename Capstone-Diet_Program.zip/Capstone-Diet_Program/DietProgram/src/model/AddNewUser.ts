export class AddNewUser{
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    phone:number;
    mail:string;
    address:string;
    city:string;
    state:string;
    country:string;
    pinCode:number;
    height:number;
    weight:number;
    diet:string;
    bmi:number;
}