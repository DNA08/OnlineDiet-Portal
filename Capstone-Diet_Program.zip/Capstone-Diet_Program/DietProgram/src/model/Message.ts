export class MessageBody{
    message:string;
    sender:string;
}