import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { Router, RouterModule } from '@angular/router';
import { PendingRequest } from 'src/model/pendingRequest';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  newUser:PendingRequest;
  constructor(private service:DataServiceService, private router:Router) { }

  ngOnInit() {
  }
  submit(regUser:PendingRequest){
    this.router.navigate(['/registerSuccessful']);
    this.service.getNewUserDetail(regUser).subscribe(resp=>{
      console.log(resp);
    });
  }

}
