import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MessageBody } from 'src/model/Message';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  
 
  private baseUrl : string;
  constructor(private http:HttpClient) { 
    this.baseUrl = 'http://localhost:8080';
  }

  uploadFileToDB(file: File,userType:string): Observable<HttpEvent<{}>>{
    let formData: FormData = new FormData();
    formData.append('file', file);
    const req = new HttpRequest('POST',`${this.baseUrl}/${userType}`,formData,
    {
      reportProgress:true,
      responseType:'text'
    });
    return this.http.request(req);
  }

  getMessages() {
    return this.http.get<MessageBody[]>(`${this.baseUrl}/above25Messages`);
  }
  deleteMessage(id:number,arg0: string) {
    const url = `${this.baseUrl}/${arg0}/${id}`;
    return this.http.get(url);  
  }

  getFiles(userType:string): Observable<any> {
      const url = `${this.baseUrl}/${userType}/all`; 
      return this.http.get(url);
  }
  deleteFile(id: number, userType:string):Observable<any> {
    const url = `${this.baseUrl}/${userType}/${id}`;
    return this.http.get(url);
  }

  uploadMessage(msgBody:MessageBody,userType:string) {
    const url = `${this.baseUrl}/${userType}`;
    return this.http.post<MessageBody>(url,msgBody);
  }

  fetchAllMessages(userType:string) {
    const url = `${this.baseUrl}/${userType}`;
    return this.http.get<MessageBody[]>(url);
  }

}
