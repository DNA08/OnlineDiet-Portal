import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { LoginUser } from 'src/model/LoginUser';
import { LoginOutput} from 'src/model/LoginOutput';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUser:LoginUser;
  loginOutput:LoginOutput;
  invalidPassword:boolean = false ;
  notregistered:boolean = false;
  userType:string;
  userClass:string;
  constructor(private dataService:DataServiceService, private router:Router) { }

  ngOnInit() {
  }

  login(user:LoginUser){ 
    
    this.dataService.postLoginDetails(user).subscribe(response=>{
        this.loginOutput = response;
        this.userType = response.userType;
        this.userClass = response.userClass;
        this.dataService.setLoginSession(response.verified);

        if(response.verified==false){
          this.notregistered = true;
          this.invalidPassword=false;
        }
        else if(response.verified == true && response.userType=="other"){
          this.invalidPassword = true;
          this.notregistered = false;
        }
        else if(response.userClass == "admin"){
          this.router.navigate(['/adminHome']);
        }
        else if(response.userType == "below"){
          this.router.navigate(['/user/below25User']);
        }
        else if(response.userType == "above"){
          this.router.navigate(['/user/above25User']);
        }
      });
  }
}
