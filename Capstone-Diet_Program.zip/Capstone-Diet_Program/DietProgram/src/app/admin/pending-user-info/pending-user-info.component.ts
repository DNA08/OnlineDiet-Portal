import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataServiceService } from 'src/app/data-service.service';
import { PendingRequest } from 'src/model/pendingRequest';
import { Location } from '@angular/common';

@Component({
  selector: 'app-pending-user-info',
  templateUrl: './pending-user-info.component.html',
  styleUrls: ['./pending-user-info.component.css']
})
export class PendingUserInfoComponent implements OnInit {

  user:PendingRequest;
  userType:string;

  constructor(private activeRoute:ActivatedRoute, private dataService:DataServiceService,
    private location:Location) { }

  ngOnInit() {
    const id = this.activeRoute.snapshot.paramMap.get('id');
    this.dataService.getPendingUserDetailById(id).subscribe(resp=>{
      this.user = resp;
    })
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }

  back(){
    this.location.back();
  }

}
