import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingUserInfoComponent } from './pending-user-info.component';

describe('PendingUserInfoComponent', () => {
  let component: PendingUserInfoComponent;
  let fixture: ComponentFixture<PendingUserInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingUserInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingUserInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
