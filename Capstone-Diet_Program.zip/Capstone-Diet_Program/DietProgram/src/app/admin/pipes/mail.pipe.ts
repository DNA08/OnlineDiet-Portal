import { Pipe, PipeTransform } from '@angular/core';
import { AddNewUser } from 'src/model/AddNewUser';

@Pipe({
  name: 'mailPipe'
})
export class MailPipe implements PipeTransform {

  transform(users: AddNewUser[], key : string): AddNewUser[] {
    if(key == null || users == null){
      return users;
    }
    else{
      return users.filter(tempUser=>
        tempUser.mail.toLowerCase().startsWith(key.toLowerCase())
      )
  }
}

}
