import { Component, OnInit } from '@angular/core';
import { AddNewUser } from 'src/model/AddNewUser';
import { DataServiceService } from 'src/app/data-service.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {

  key:string;
  allUsers:AddNewUser[];
  private userType:string;
  
  
  constructor(private dataService:DataServiceService) {
   }

  ngOnInit() {
    this.getAllUsers();
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }

  getAllUsers(){
    this.dataService.getAllUsers().subscribe(resp=>{
      this.allUsers = resp;
  });
  }

  changeTo(type:string,user:AddNewUser){
    this.dataService.changeUserType(type,user).subscribe(resp=>{
      console.log(resp);
    });
  }

  deleteUser(user:AddNewUser){
    this.dataService.deleteUser(user).subscribe(temp=>{
      this.getAllUsers();
    }); 
  }

}
