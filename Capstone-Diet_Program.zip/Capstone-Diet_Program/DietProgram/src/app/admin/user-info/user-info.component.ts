import { Component, OnInit } from '@angular/core';
import { DataServiceService } from 'src/app/data-service.service';
import { ActivatedRoute } from '@angular/router';
import { AddNewUser } from 'src/model/AddNewUser';
import {Location } from '@angular/common';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent implements OnInit {

  id:string;
  user:AddNewUser;
  constructor(private dataService:DataServiceService, private activeRoute:ActivatedRoute,
    private location:Location) { } 

    userType:string;
    
  ngOnInit() {
    this.id = this.activeRoute.snapshot.paramMap.get('id');
    this.dataService.getUserDetailById(this.id).subscribe(resp=>{
      this.user = resp;
    })
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }
  back(){
    this.location.back();
  }

}
