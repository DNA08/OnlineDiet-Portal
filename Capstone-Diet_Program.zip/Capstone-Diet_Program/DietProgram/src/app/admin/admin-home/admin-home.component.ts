import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/data-service.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  userType:string;
  
  constructor(private router:Router, private dataService:DataServiceService) { }

  ngOnInit() {
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }

  logOut(){
    this.router.navigate(['/']);
  }

}
