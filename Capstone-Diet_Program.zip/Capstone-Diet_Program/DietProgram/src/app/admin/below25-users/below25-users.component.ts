import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AddNewUser } from 'src/model/AddNewUser';
import { MessageBody } from 'src/model/Message';
import { FileService } from 'src/app/file.service';
import { DataServiceService } from 'src/app/data-service.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-below25-users',
  templateUrl: './below25-users.component.html',
  styleUrls: ['./below25-users.component.css']
})
export class Below25UsersComponent implements OnInit {

  uploadFile : File;
  allFiles: FileList;
  selectedFiles;
  allExistingFiles: Observable<string[]>;
  showSelectedFile:boolean=false;
  progress: { percentage: number } = { percentage: 0 }

  below25Users:AddNewUser[]=[];
  allUsers:AddNewUser[];

  msgBody:MessageBody={"message":"","sender":""};
  msgBodyArr:MessageBody[];
  messagesLength=false;
  msgBoxEmpty:string='';

  userType:string;
  constructor(private service:FileService, private dataService:DataServiceService) { 
    
  }

  ngOnInit() {
    this.getAllFiles();
    this.getAllMessages();
    this.getAllUsers(); 
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    }) 
  }

  getAllFiles(){
    this.service.getFiles("belowFile").subscribe(resp=>{
      this.allExistingFiles = resp;
    });
  }

  getAllMessages(){
    this.service.fetchAllMessages("below25Messages").subscribe(resp=>{
      this.msgBodyArr = resp;
    })
  }

  getAllUsers(){
    this.dataService.getAllUsers().subscribe(resp=>{
      this.allUsers=resp;
      this.getBelow25Users();
    })
  }

  getBelow25Users(){
    this.below25Users = this.allUsers.filter(function(ele){
      return ele.bmi<=25.0;
    })
  }

  onSelectFile(event){
    this.selectedFiles = event.target.files;
    this.showSelectedFile = true;
  }

  uploadFiles(){
    this.progress.percentage=0;
    this.uploadFile = this.selectedFiles[0];
    this.service.uploadFileToDB(this.uploadFile, "belowFileUpload").subscribe(event=>{
      if(event.type === HttpEventType.UploadProgress){
        this.progress.percentage = Math.round(100*event.loaded/event.total);
      }else if(event instanceof HttpResponse){
        console.log("file is completly uploaded");
      }
      this.getAllFiles();
    })
    this.showSelectedFile=false;
  }

  deleteFile(id:number){
    this.service.deleteFile(id,"deleteBelow").subscribe(response=>{
      this.getAllFiles();
    })
  }

  postMessage(msg){
    this.msgBody.sender = this.dataService.getCurrentUser();
    this.msgBody.message = msg.text;
    this.service.uploadMessage(this.msgBody, "below25Message").subscribe(event=>{
      this.getAllMessages();
      this.msgBoxEmpty='';      
    });
  }
  deleteMessage(id:number){
    this.service.deleteMessage(id,"deleteBelowMessage").subscribe(temp=>{
      this.getAllMessages();
    })
  }

}
