import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Below25UsersComponent } from './below25-users.component';

describe('Below25UsersComponent', () => {
  let component: Below25UsersComponent;
  let fixture: ComponentFixture<Below25UsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Below25UsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Below25UsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
