import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PendingRequestComponent } from './pending-request/pending-request.component';
import { AllUsersComponent } from './all-users/all-users.component';
import { Below25UsersComponent } from './below25-users/below25-users.component';
import { Above25FilesComponent } from './above25/above25.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { HttpClientModule } from '@angular/common/http';
import { PendingUserInfoComponent } from './pending-user-info/pending-user-info.component';
import { MailPipe } from './pipes/mail.pipe';



@NgModule({
  declarations: [AdminHomeComponent, PendingRequestComponent, AllUsersComponent,
    Below25UsersComponent, Above25FilesComponent, UserInfoComponent,PendingUserInfoComponent, MailPipe],
  imports: [
    CommonModule, HttpClientModule,FormsModule, RouterModule.forRoot([
      {
        path: 'adminHome', component: AdminHomeComponent, children: [

          { path: 'pendingRequest', component: PendingRequestComponent },
          { path: 'allUsers', component: AllUsersComponent },
          { path: 'above25Users', component: Above25FilesComponent },
          { path: 'below25Users', component: Below25UsersComponent },
          { path: 'userInfo/:id', component: UserInfoComponent },
          { path: 'allUsers/userInfo/:id', component: UserInfoComponent },
          { path: 'pendingRequest/userInfo/:id', component: PendingUserInfoComponent },
        ]
      }
    ])
  ],
  exports: [
    AdminHomeComponent
  ]
})
export class AdminModule { }
