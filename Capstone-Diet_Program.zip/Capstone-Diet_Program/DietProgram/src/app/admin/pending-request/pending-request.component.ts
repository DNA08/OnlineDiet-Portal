import { Component, OnInit } from '@angular/core';
import { PendingRequest } from 'src/model/pendingRequest';
import { DataServiceService } from 'src/app/data-service.service';

@Component({ 
  selector: 'app-pending-request',
  templateUrl: './pending-request.component.html',
  styleUrls: ['./pending-request.component.css']
})
export class PendingRequestComponent implements OnInit {

  userType:string;
  pendingRequests:PendingRequest [];
  constructor(private dataService:DataServiceService) { }

  ngOnInit() {
    this.getAllPendingRequests();
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }

  getAllPendingRequests(){
    this.dataService.getAllPendingRequest().subscribe(resp=>{
      this.pendingRequests = resp;
      })
  }

  approveUser(user:PendingRequest){
    this.dataService.sendPositiveResponse(user).subscribe(resp=>{
      this.getAllPendingRequests();
    });
  }

  rejectUser(user:PendingRequest){
    this.dataService.sendNegativeResponse(user).subscribe(resp=>{
      this.getAllPendingRequests();
    });
  }
  
}
