import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FileService } from 'src/app/file.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { DataServiceService } from 'src/app/data-service.service';
import { AddNewUser } from 'src/model/AddNewUser';
import { MessageBody } from 'src/model/Message'; 

@Component({
  selector: 'app-above25-files',
  templateUrl: './above25.component.html',
  styleUrls: ['./above25.component.css']
})
export class Above25FilesComponent implements OnInit {
 
  uploadFile : File; 
  allFiles: FileList;
  selectedFiles;
  allExistingFiles: Observable<string[]>;
  showSelectedFile:boolean=false;
  progress: { percentage: number } = { percentage: 0 }

  above25Users:AddNewUser[]=[];
  allUsers:AddNewUser[];
  
  msgBody:MessageBody={"message":"","sender":""};
  msgBodyArr:MessageBody[];
  messagesLength=false;
  msgBoxEmpty:string='';
  userType:string;


  constructor(private service:FileService, private dataService:DataServiceService) { 
    
  }

  ngOnInit() {
    this.getAllFiles();
    this.getAllMessages();
    this.getAllUsers();  
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
  }

  getAllFiles(){
    this.service.getFiles("abovefile").subscribe(resp=>{
      this.allExistingFiles = resp;
    });
  }

  getAllMessages(){
    this.service.fetchAllMessages("above25Messages").subscribe(resp=>{
      this.msgBodyArr = resp;
    })
  }

  getAllUsers(){
    this.dataService.getAllUsers().subscribe(resp=>{
      this.allUsers=resp;
      this.getAbove25Users();
    })
  }

  getAbove25Users(){
    this.above25Users = this.allUsers.filter(function(temp){
      return temp.bmi>25.0;
    })
  }

  onSelectFile(event){
    this.selectedFiles = event.target.files;
    this.showSelectedFile = true;
  }

  uploadFiles(){
    this.progress.percentage=0;
    this.uploadFile = this.selectedFiles[0];
    this.service.uploadFileToDB(this.uploadFile,"aboveFileUpload").subscribe(event=>{
      if(event.type === HttpEventType.UploadProgress){
        this.progress.percentage = Math.round(100*event.loaded/event.total);
      }else if(event instanceof HttpResponse){
        console.log("file is completly uploaded");
      }
      this.getAllFiles();
    })
    this.showSelectedFile=false;
  }

  deleteFile(id:number){
    this.service.deleteFile(id,"deleteAbove").subscribe(response=>{
      this.getAllFiles();
    })
  }

  postMessage(msg){
    this.msgBody.sender = this.dataService.getCurrentUser();
    this.msgBody.message = msg.text;
    this.service.uploadMessage(this.msgBody,"above25Message").subscribe(event=>{
      this.getAllMessages();
      this.msgBoxEmpty='';      
    });
  }

  deleteMessage(id:number){
    this.service.deleteMessage(id,"deleteAboveMessage").subscribe(temp=>{
      this.getAllMessages();
    })
  }

}
