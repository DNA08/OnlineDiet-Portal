import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Above25FilesComponent } from './above25.component';

describe('Above25FilesComponent', () => {
  let component: Above25FilesComponent;
  let fixture: ComponentFixture<Above25FilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Above25FilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Above25FilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
