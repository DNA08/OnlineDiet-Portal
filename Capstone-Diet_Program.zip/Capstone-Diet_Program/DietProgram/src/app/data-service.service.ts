import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginUser } from 'src/model/LoginUser';
import { LoginOutput } from 'src/model/LoginOutput';
import { PendingRequest } from 'src/model/pendingRequest';
import { AddNewUser } from 'src/model/AddNewUser';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {
  
  

  url:string;
  currentUser:string;
  userType:string;
  userClass:string;
  loginUser:LoginUser;
  session:boolean;

  constructor(private http: HttpClient) {
  }

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  getAllUsers() {
    return this.http.get<AddNewUser[]>('http://localhost:8080/getAllUserDetails');
  }

  getLoggedInUser() {
   return this.http.get<AddNewUser>(`http://localhost:8080/getUserDetailsByEmailId/${this.currentUser}`);
  }

  getLoggedInUserforType() {
    return this.http.get<LoginUser>(`http://localhost:8080/getUserCredDetailsByEmailId/${this.currentUser}`);
   }

  getNewUserDetail(regUser) {
    console.log("sssss0");
    return this.http.post<PendingRequest>(('http://localhost:8080/register'), regUser,this.httpOptions);
  }

  deleteUser(user: AddNewUser) {
    return this.http.post('http://localhost:8080/deleteUser',user);
  }
  sendPositiveResponse(user:PendingRequest) {
    console.log('Accepting User Request');
    return this.http.post<PendingRequest>('http://localHost:8080/acceptUser',user);
  }
  
  sendNegativeResponse(user:PendingRequest) {
    console.log('Rejecting User Request');
    return this.http.post<PendingRequest>('http://localHost:8080/rejectUser',user);
  }

  getAllPendingRequest() {
    return this.http.get<PendingRequest[]>('http://localhost:8080/adminView');
  }

  postLoginDetails(user: LoginUser) {
    this.currentUser = user.email;
    
    console.log(this.currentUser+"  logged in user email id is");
    return this.http.post<LoginOutput>('http://localhost:8080/login', user);
  }

  getCurrentUser(){
    return this.currentUser;
  }

  getUserDetailById(id) {
    console.log(id+"  inside service");
    return this.http.get<AddNewUser>(`http://localhost:8080/getUserDetailsByEmailId/${id}`);  
  }

  getPendingUserDetailById(id) {
    return this.http.get<PendingRequest>(`http://localhost:8080/getPendingUserDetailsByEmailId/${id}`); 
     
  }

  setUserClass(userClass: string) {
    this.userClass = userClass;
  }

  changeUserType(userType:string,user:AddNewUser) {
    return this.http.post<string>(`http://localhost:8080/changeUserType/${userType}`,user);
  } 

  setLoginSession(verified: boolean) {
    this.session = verified;
  }

  getLoginSession(){
    return this.session;
  }
}
