import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserHomeComponent } from './user-home/user-home.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Below25UserComponent } from './below25-user/below25-user.component';
import { Above25UserComponent } from './above25-user/above25-user.component';



@NgModule({
  declarations: [UserHomeComponent, Below25UserComponent, Above25UserComponent],
  imports: [
    CommonModule,FormsModule, RouterModule.forRoot([
     {path:'user', component:UserHomeComponent, children:[
       {path:'below25User', component:Below25UserComponent},
       {path:'above25User', component:Above25UserComponent} 
     ]},
    ])
  ],
  exports:[
    UserHomeComponent,Above25UserComponent,Below25UserComponent
  ]
})
export class UserModule { }
