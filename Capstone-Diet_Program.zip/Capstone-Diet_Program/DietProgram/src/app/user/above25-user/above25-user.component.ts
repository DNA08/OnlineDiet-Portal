import { Component, OnInit } from '@angular/core';
import { DataServiceService } from 'src/app/data-service.service';
import { FileService } from 'src/app/file.service';
import { MessageBody } from 'src/model/Message';
import { AddNewUser } from 'src/model/AddNewUser';
import { Observable } from 'rxjs';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-above25-user',
  templateUrl: './above25-user.component.html',
  styleUrls: ['./above25-user.component.css']
})
export class Above25UserComponent implements OnInit {

  constructor(private dataService:DataServiceService, private fileService:FileService,
    private router:Router) { }

  files:Observable<string[]>;
  msgBodyArr:MessageBody[];
  mail:string;
  
  user:AddNewUser;
  msgBody:MessageBody={"message":"","sender":""};
  uploadFile : File;
  allFiles: FileList;
  selectedFiles;
  showSelectedFile:boolean=false;
  messagesLength=false;
  progress: { percentage: number } = { percentage: 0 }
  userType:string;

  showView:boolean = false;

  ngOnInit() {
    this.dataService.getLoggedInUser().subscribe(resp=>{
      this.user = resp;
    })
    this.fileService.getFiles("abovefile").subscribe(resp=>{
      this.files = resp;
    })

    this.fileService.fetchAllMessages("above25Messages").subscribe(resp=>{
      this.msgBodyArr = resp;
    })
    this.dataService.getLoggedInUserforType().subscribe(temp=>{
        this.userType = temp.type;
        if(this.userType=='User' || this.userType=='Moderator'){
          this.showView=true;
        }
      });
  }

  postMessage(msg){
    this.msgBody.sender = this.dataService.getCurrentUser();
    this.msgBody.message = msg.text;
    this.fileService.uploadMessage(this.msgBody,"above25Message").subscribe(event=>{
      this.ngOnInit();
    });
  }

  onSelectFile(event){
    this.selectedFiles = event.target.files;
    this.showSelectedFile = true;
  }
  
  uploadFiles(){
    this.progress.percentage=0;
    this.uploadFile = this.selectedFiles[0];
    this.fileService.uploadFileToDB(this.uploadFile,"aboveFileUpload").subscribe(event=>{
      if(event.type === HttpEventType.UploadProgress){
        this.progress.percentage = Math.round(100*event.loaded/event.total);
      }else if(event instanceof HttpResponse){
        console.log("file is completly uploaded");
      }
      this.ngOnInit();
    })
  }

  deleteFile(id:number){
    this.fileService.deleteFile(id,"deleteAbove").subscribe(response=>{
      this.ngOnInit();
    })
  }

  logOut(){
    this.router.navigate(['/']);
  }
}
