import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Above25UserComponent } from './above25-user.component';

describe('Above25UserComponent', () => {
  let component: Above25UserComponent;
  let fixture: ComponentFixture<Above25UserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Above25UserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Above25UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
