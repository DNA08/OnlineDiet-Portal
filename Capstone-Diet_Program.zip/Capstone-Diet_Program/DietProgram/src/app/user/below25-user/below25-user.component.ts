import { Component, OnInit } from '@angular/core';
import { DataServiceService } from 'src/app/data-service.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MessageBody } from 'src/model/Message';
import { AddNewUser } from 'src/model/AddNewUser';
import { FileService } from 'src/app/file.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-below25-user',
  templateUrl: './below25-user.component.html',
  styleUrls: ['./below25-user.component.css']
})
export class Below25UserComponent implements OnInit {

  constructor(private dataService:DataServiceService, private fileService:FileService,
    private router:Router) { }

  files:Observable<string[]>;
  msgBodyArr:MessageBody[];
  mail:string;
  showView:boolean = false;
  user:AddNewUser;
  msgBody:MessageBody={"message":"","sender":""};
  uploadFile : File;
  allFiles: FileList;
  selectedFiles;
  allExistingFiles: Observable<string[]>;
  showSelectedFile:boolean=false;
  above25Users:AddNewUser[];
  messagesLength=false;
  session:boolean;

  progress: { percentage: number } = { percentage: 0 }
  
  userType:string;

  ngOnInit() {

    console.log(this.session);

    this.dataService.getLoggedInUser().subscribe(resp=>{
      this.user = resp;
    })

    this.fileService.getFiles("belowFile").subscribe(resp=>{
      this.files = resp;
    })
    this.fileService.fetchAllMessages("below25Messages").subscribe(resp=>{
      this.msgBodyArr = resp;
    })

    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
    })
    this.mail = this.dataService.getCurrentUser();

    this.dataService.getLoggedInUserforType().subscribe(temp=>{
      this.userType = temp.type;
      if(this.userType=='User' || this.userType=='Moderator'){
        this.showView=true;
      }
    });
  }

  postMessage(msg){
    this.msgBody.sender = this.dataService.getCurrentUser();
    this.msgBody.message = msg.text;
    this.fileService.uploadMessage(this.msgBody,"below25Message").subscribe(event=>{
      this.ngOnInit();
    });
  }

  onSelectFile(event){
    this.selectedFiles = event.target.files;
    this.showSelectedFile = true;
  }
  
  uploadFiles(){
    this.progress.percentage=0;
    this.uploadFile = this.selectedFiles[0];
    this.fileService.uploadFileToDB(this.uploadFile,"belowFileUpload").subscribe(event=>{
      if(event.type === HttpEventType.UploadProgress){
        this.progress.percentage = Math.round(100*event.loaded/event.total);
      }else if(event instanceof HttpResponse){
        console.log("file is completly uploaded");
      }
      this.ngOnInit();
    })
  }

  deleteFile(id:number){
    this.fileService.deleteFile(id,"belowAbove").subscribe(response=>{
      this.ngOnInit();
    })
  }

  logOut(){
    this.showView = false;
    this.router.navigate(['/']);
  }

  
    
}
