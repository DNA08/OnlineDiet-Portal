import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Below25UserComponent } from './below25-user.component';

describe('Below25UserComponent', () => {
  let component: Below25UserComponent;
  let fixture: ComponentFixture<Below25UserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Below25UserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Below25UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
