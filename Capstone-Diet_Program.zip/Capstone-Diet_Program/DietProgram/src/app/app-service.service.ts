import { Injectable } from '@angular/core';
import { AddNewUser } from '../model/AddNewUser';
import { Observable } from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppServiceService {


  private baseUrl:String;

  
  httpOptions={
    headers: new HttpHeaders({'Content-Type':'application/json'})
  };

  constructor(private http:HttpClient) {
    this.baseUrl = '';
   }

  registerUSer(user:AddNewUser):Observable<boolean>{
    console.log("User Registered");
    const newUrl = `${this.baseUrl}/addUser`;
    return this.http.post<boolean>(newUrl,user,this.httpOptions);
  }
}
