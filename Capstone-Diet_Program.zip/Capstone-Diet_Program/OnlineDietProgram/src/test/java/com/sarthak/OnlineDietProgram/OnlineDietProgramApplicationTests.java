package com.sarthak.OnlineDietProgram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineDietProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
