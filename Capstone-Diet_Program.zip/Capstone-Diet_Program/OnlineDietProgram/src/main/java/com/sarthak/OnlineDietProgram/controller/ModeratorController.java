package com.sarthak.OnlineDietProgram.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sarthak.OnlineDietProgram.entity.ModeratorEntity;
import com.sarthak.OnlineDietProgram.service.ModeratorService;

//@CrossOrigin(origins = "http://locaLhost:4200")
@RestController
public class ModeratorController {

	@Autowired
	ModeratorService moderatorService;
	
	
	@RequestMapping(value = "/addModerator", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public void handleMessagesOver25(@RequestBody ModeratorEntity moderatorEntity) {

		moderatorService.addModerator(moderatorEntity);
	}

}
