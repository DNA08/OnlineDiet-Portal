package com.sarthak.OnlineDietProgram.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sarthak.OnlineDietProgram.entity.Above25MessageEntity;

@Repository
public interface Above25MessageRepo extends JpaRepository<Above25MessageEntity, Long> {

}
