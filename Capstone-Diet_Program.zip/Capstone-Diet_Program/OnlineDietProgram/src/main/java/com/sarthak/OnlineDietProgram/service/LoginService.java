package com.sarthak.OnlineDietProgram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarthak.OnlineDietProgram.entity.LoginInput;
import com.sarthak.OnlineDietProgram.entity.LoginOutput;
import com.sarthak.OnlineDietProgram.entity.PendingRequestEntity;
import com.sarthak.OnlineDietProgram.entity.UserCredEntity;
import com.sarthak.OnlineDietProgram.entity.UserEntity;
import com.sarthak.OnlineDietProgram.repository.UserCredRepo;

@Service
public class LoginService {

	@Autowired
	AdminService adminService;

	@Autowired
	UserCredRepo userCredRepo;

	@Autowired
	UserService userService;

	@Autowired
	ModeratorService moderatorService;


	public LoginOutput validate(LoginInput input) {
		LoginOutput output = new LoginOutput();
		UserCredEntity userCred = new UserCredEntity();
		String mail = input.getEmail();
		String password = input.getPassword();
		System.out.println("Email id for login is="+input.getEmail());
		if (userCredRepo.existsById(input.getEmail())) {
			output.setVerified(true);
			System.out.println("Credentials found .. Resolving User type......");
			if (mail.equals("sarthak@gmail.com")){
				if(password.equals("wipro@123")){
					output.setUserClass("admin");
					output.setUserType("NA");
				}else{
					output.setUserType("other");
				}
			}else {
				userCred = userCredRepo.findByMail(mail);
				if(password.equals(userCred.getPassword())){
					UserEntity user = userService.getUserByMail(mail);
					double bmi = user.getWeight() * 10000 / (user.getHeight() * user.getHeight());
					output.setVerified(true);
					if (bmi >= 25.0) {
						output.setUserType("above");
					} else {
						output.setUserType("below");
					}
					if (moderatorService.isModerator(mail))
						output.setUserClass("moderator");
					else
						output.setUserClass("user");
				}else {
					output.setUserType("other");
				}
			}
		}else {
			System.out.println("Creentials not found");
			output.setVerified(false);
			output.setUserType(null);
			output.setUserClass(null);
		}
		return output;
	}
}
