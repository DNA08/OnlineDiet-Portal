package com.sarthak.OnlineDietProgram.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sarthak.OnlineDietProgram.entity.Above25FilesEntity;
import com.sarthak.OnlineDietProgram.entity.Above25MessageEntity;
import com.sarthak.OnlineDietProgram.entity.Below25FilesEntity;
import com.sarthak.OnlineDietProgram.entity.Below25MessageEntity;
import com.sarthak.OnlineDietProgram.service.AdminService;
import com.sarthak.OnlineDietProgram.service.LoginService;
import com.sarthak.OnlineDietProgram.service.MessageFileService;
import com.sarthak.OnlineDietProgram.service.UserService;

@CrossOrigin(origins = "http://locaLhost:4200")
@RestController
public class FetchFileMessageController {

	@Autowired
	UserService userService;

	@Autowired
	AdminService adminService;

	@Autowired
	LoginService loginService;

	@Autowired
	MessageFileService messageFileService;

	@PostMapping("above25Message")
	public void handleMessagesOver25(@RequestBody Above25MessageEntity message) {

		System.out.println(message.getMessage()+" jhbhuh   "+message.getSender());
		messageFileService.addNewMessageAbove25(message);
	}

	@PostMapping("/below25Message")
	public void handleMessagesBelow25(@RequestBody Below25MessageEntity message) {
		messageFileService.addNewMessageBelow25(message);
	}
	
	@GetMapping("/deleteAboveMessage/{id}")
	public void deleteMessageAbove(@PathVariable("id") long id){
		messageFileService.deleteAboveMessage(id);
	}
	
	@GetMapping("/deleteBelowMessage/{id}")
	public void deleteMessageBelow(@PathVariable("id") long id){
		messageFileService.deleteBelowMessage(id);
	}

	@GetMapping("/below25Messages")
	public List<Below25MessageEntity> getMessagesBelow25() {
		return messageFileService.getAllMessagesBelow();
	}


	@GetMapping("/above25Messages")
	public List<Above25MessageEntity> getMessagesAbove25() {
		return messageFileService.getAllMessagesAbove();
	}
	
	
	@PostMapping("aboveFileUpload")
	public String uploadAboveFile(@RequestBody MultipartFile file){
		return messageFileService.uploadFileAbove25(file);
	}
	
	@GetMapping("/abovefile/all")
	public List<Above25FilesEntity> getAboveFiles() {
	    return messageFileService.getAllAboveFiles();
	}
	
	@GetMapping("/aboveFile/{id}")
	public ResponseEntity<byte[]> getAboveFile(@PathVariable("id") long id){
		return messageFileService.getFileAbove(id);
	}
	
	@PostMapping("belowFileUpload")
	public String uploadBelowFile(@RequestBody MultipartFile file){
		return messageFileService.uploadFileBelow25(file);
	}
	
	@GetMapping("/belowFile/all")
	public List<Below25FilesEntity> getBelowFiles() {
	    return messageFileService.getAllBelowFiles();
	}
	
	@GetMapping("/belowFile/{id}")
	public ResponseEntity<byte[]> getBelowFile(@PathVariable("id") long id){
		return messageFileService.getFilebelow(id);
	}
	
	@GetMapping("deleteAbove/{id}")
	public void deleteAboveFile(@PathVariable("id") long id){
		messageFileService.deleteAboveFile(id);
	}

	@GetMapping("deleteBelow/{id}")
	public void deleteBelowFile(@PathVariable("id") long id){
		messageFileService.deleteBelowFile(id);
	}
}
