package com.sarthak.OnlineDietProgram.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sarthak.OnlineDietProgram.controller.MainController;
import com.sarthak.OnlineDietProgram.entity.Above25FilesEntity;
import com.sarthak.OnlineDietProgram.entity.Above25MessageEntity;
import com.sarthak.OnlineDietProgram.entity.Below25FilesEntity;
import com.sarthak.OnlineDietProgram.entity.Below25MessageEntity;
import com.sarthak.OnlineDietProgram.repository.Above25FileRepo;
import com.sarthak.OnlineDietProgram.repository.Above25MessageRepo;
import com.sarthak.OnlineDietProgram.repository.Below25FileRepo;
import com.sarthak.OnlineDietProgram.repository.Below25MessageRepo;


@Service
public class MessageFileService {
	
	@Autowired
	Above25MessageRepo above25Message;
	
	@Autowired
	Above25FileRepo above25File;
	
	@Autowired
	Below25MessageRepo below25Message;
	
	@Autowired
	Below25FileRepo below25File;
	
	
	
//	Message Services
	public void addNewMessageAbove25(Above25MessageEntity userEntity) {
//		userEntity.setSender(this.mailId);
		above25Message.save(userEntity);
	}
	
	public void addNewMessageBelow25(Below25MessageEntity userEntity) {
//		userEntity.setSender(mailId);
		below25Message.save(userEntity);
	}
	
	public List<Above25MessageEntity> getAllMessagesAbove(){
		return above25Message.findAll();
	}
	
	public List<Below25MessageEntity> getAllMessagesBelow(){
		return below25Message.findAll();
	}
	
	public void deleteAboveMessage(long id){
		above25Message.deleteById(id);;
	}
	
	public void deleteBelowMessage(long id){
		below25Message.deleteById(id);
	}
	
//	File Service
	
	public String uploadFileAbove25(MultipartFile file){
		Above25FilesEntity uploadedFile = new Above25FilesEntity();
		uploadedFile.setFileName(file.getOriginalFilename());
		uploadedFile.setMimeType(file.getContentType());
		try {
			uploadedFile.setFile(file.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "File uploading failed";
		}
		above25File.save(uploadedFile);
		return "File uploaded successfully.....";
	}
	
	public String uploadFileBelow25(MultipartFile file){
		Below25FilesEntity uploadedFile = new Below25FilesEntity();
		uploadedFile.setFileName(file.getOriginalFilename());
		uploadedFile.setMimeType(file.getContentType());
		try {
			uploadedFile.setFile(file.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "File uploading failed";
		}
		below25File.save(uploadedFile);
		return "File uploaded successfully.....";
	}
	
	public List<Above25FilesEntity> getAllAboveFiles(){
		return above25File.findAll();
	}
	
	public List<Below25FilesEntity> getAllBelowFiles(){
		return below25File.findAll();
	}
	
	public ResponseEntity<byte[]> getFileAbove(long id){
		Optional<Above25FilesEntity> file = above25File.findById(id);
		if(file.isPresent()){
			Above25FilesEntity desiredFile = file.get();
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; fileName=\""+ desiredFile.getFileName()+"\"")
					.contentType(MediaType.parseMediaType(desiredFile.getMimeType()))
					.body(desiredFile.getFile());
		}
		return ResponseEntity.status(404).body(null);
	}
	
	public ResponseEntity<byte[]> getFilebelow(long id){
		Optional<Below25FilesEntity> file = below25File.findById(id);
		if(file.isPresent()){
			Below25FilesEntity desiredFile = file.get();
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; fileName="+ desiredFile.getFileName())
					.contentType(MediaType.parseMediaType(desiredFile.getMimeType()))
					.body(desiredFile.getFile());
		}
		return ResponseEntity.status(404).body(null);
	}
	
	public void deleteBelowFile(long id){
		below25File.deleteById(id);
	}
	
	public void deleteAboveFile(long id){
		above25File.deleteById(id);
	}
	
}
