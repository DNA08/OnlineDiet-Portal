package com.sarthak.OnlineDietProgram.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sarthak.OnlineDietProgram.entity.Below25MessageEntity;

@Repository
public interface Below25MessageRepo extends JpaRepository<Below25MessageEntity, Long> {

}
