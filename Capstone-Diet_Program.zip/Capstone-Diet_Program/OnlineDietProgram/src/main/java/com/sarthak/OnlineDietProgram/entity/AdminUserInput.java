package com.sarthak.OnlineDietProgram.entity;

public class AdminUserInput {
	
	private PendingRequestEntity pendingRequestEntity;
	private boolean accept;
	
	public PendingRequestEntity getPendingRequestEntity() {
		return pendingRequestEntity;
	}
	public void setPendingRequestEntity(PendingRequestEntity pendingRequestEntity) {
		this.pendingRequestEntity = pendingRequestEntity;
	}
	public boolean isAccept() {
		return accept;
	}
	public void setAccept(boolean accept) {
		this.accept = accept;
	}
	
	
}
