package com.sarthak.OnlineDietProgram.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarthak.OnlineDietProgram.entity.ModeratorEntity;
import com.sarthak.OnlineDietProgram.repository.ModeratorRepo;

@Service
public class ModeratorService {
	
	@Autowired
	ModeratorRepo moderatorRepo;

	public void addModerator(ModeratorEntity moderatorEntity){
		
		moderatorRepo.save(moderatorEntity);
	}
	
	public boolean isModerator(String email){
		if(moderatorRepo.existsById(email))
			return true;
		return false;
	}
}
