package com.sarthak.OnlineDietProgram.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ModeratorEntity")
public class ModeratorEntity {
	
	@Id
	private String email;

	public String getUserName() {
		return email;
	}

	public void setUserName(String email) {
		this.email = email;
	}
	
	
}
