package com.sarthak.OnlineDietProgram.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sarthak.OnlineDietProgram.entity.ModeratorEntity;

@Repository
public interface ModeratorRepo extends JpaRepository<ModeratorEntity,String>{

}
