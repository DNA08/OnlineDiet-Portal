package com.sarthak.OnlineDietProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineDietProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineDietProgramApplication.class, args);
	}

}
