package com.sarthak.OnlineDietProgram.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sarthak.OnlineDietProgram.entity.Above25FilesEntity;

@Repository
public interface Above25FileRepo extends JpaRepository<Above25FilesEntity, Long>{

}
