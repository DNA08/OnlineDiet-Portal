package com.sarthak.OnlineDietProgram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarthak.OnlineDietProgram.entity.AdminUserInput;
import com.sarthak.OnlineDietProgram.entity.PendingRequestEntity;
import com.sarthak.OnlineDietProgram.entity.UserCredEntity;
import com.sarthak.OnlineDietProgram.entity.UserEntity;
import com.sarthak.OnlineDietProgram.repository.UserCredRepo;

@Service
public class AdminService {
	@Autowired
	UserService userService;
	@Autowired
	UserCredRepo userCredRepo;

	

	public String acceptUser(AdminUserInput input){
		String response = "";
		UserCredEntity userCred = new UserCredEntity();
		userCred.setMail(input.getPendingRequestEntity().getMail());
		userCred.setPassword(input.getPendingRequestEntity().getMail() + "@123");
//		if(check(input.getPendingRequestEntity())){
			userCredRepo.save(userCred);
			response = "success";
//		}
//		else
			response = "failure";
		return response;
	}
	
}
