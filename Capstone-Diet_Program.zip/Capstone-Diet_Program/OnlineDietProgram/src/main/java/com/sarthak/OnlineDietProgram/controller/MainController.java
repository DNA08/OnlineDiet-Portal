package com.sarthak.OnlineDietProgram.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sarthak.OnlineDietProgram.entity.LoginInput;
import com.sarthak.OnlineDietProgram.entity.LoginOutput;
import com.sarthak.OnlineDietProgram.entity.PendingRequestEntity;
import com.sarthak.OnlineDietProgram.entity.UserCredEntity;
import com.sarthak.OnlineDietProgram.entity.UserEntity;
import com.sarthak.OnlineDietProgram.service.AdminService;
import com.sarthak.OnlineDietProgram.service.LoginService;
import com.sarthak.OnlineDietProgram.service.MessageFileService;
import com.sarthak.OnlineDietProgram.service.UserService;

@RestController
@CrossOrigin(origins = "http://locaLhost:4200")
public class MainController { 

	@Autowired
	UserService userService;

	@Autowired
	AdminService adminService;

	@Autowired
	LoginService loginService;

	@Autowired
	MessageFileService messageFileService;

	private String emailId;


	//	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/register")
	public String registerNewUser(@RequestBody PendingRequestEntity pendingRequestEntity) {
		userService.adduser(pendingRequestEntity);
		String response = "Your details are under consideration.Please check your registered email Id";
		return response;
	}


	@GetMapping(value = "/adminView")
	public List<PendingRequestEntity> getAllPendingRequests() {
		return userService.getAllPendingRequest();
	}

	@PostMapping(value = "/rejectUser")
	public void rejectUser(@RequestBody PendingRequestEntity input) {
		userService.deleteRequest(input);	
	}

	@PostMapping(value = "/acceptUser")
	public void acceptUser(@RequestBody PendingRequestEntity input) {
		userService.acceptUser(input);
	}

	@PostMapping(value = "/login")
	public LoginOutput login(@RequestBody LoginInput input) {
		this.emailId = input.getEmail();
		System.out.println(input.getEmail()+"  from backend "+this.emailId);
		LoginOutput output = loginService.validate(input);
		return output;
	}

	@RequestMapping(value = "/getAllUserDetails", method = RequestMethod.GET, produces = "application/json")
	public List<UserEntity> getAllUser() {
		return userService.getAllUserDetail();
	}

	//	@GetMapping(value = "/getUserAbove25")
	//	public List<UserEntity> getUsersAbove25(){
	//		return userService.getAbove();
	//	}

	@GetMapping("/getPendingUserDetailsByEmailId/{mail}")
	public PendingRequestEntity getPendingUser(@PathVariable("mail") String mail) {
		return userService.getPendingUserByMail(mail);
	}
	@GetMapping("/getUserDetailsByEmailId/{mail}")
	public UserEntity getUser(@PathVariable("mail") String mail) {
		System.out.println("Fetching user by mail:"+mail);
		return userService.getUserByMail(mail);
	}

	public String getEmailId() {
		System.out.println(emailId+" in controller");
		return this.emailId;
	}

	@PostMapping("/deleteUser")
	public void deleteUser(@RequestBody UserEntity user){
		 userService.deleteUser(user);
	}

	@PostMapping("/changeUserType/{userType}")
	public void changeUserType(@RequestBody UserEntity user, @PathVariable String userType){
		 userService.setUserType(user, userType);
	}
	@PostMapping("/getUserType")
	public String returnUserType(@RequestBody UserCredEntity user){
		return userService.getUserType(user.getMail());
	}
	@GetMapping("getUserCredDetailsByEmailId/{email}")
	public UserCredEntity getUserDetail(@PathVariable String email){
		return userService.getUserDetail(email);
	}
	
}
