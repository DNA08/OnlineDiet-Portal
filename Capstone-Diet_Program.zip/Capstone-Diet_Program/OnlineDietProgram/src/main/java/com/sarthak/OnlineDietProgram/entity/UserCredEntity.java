package com.sarthak.OnlineDietProgram.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "UserCred")
public class UserCredEntity {
	
	@Id
	private String mail;
	private String password;
	private String type;
	private String bmiGroup;
	
	public String getBmiGroup() {
		return bmiGroup;
	}
	public void setBmiGroup(String bmiGroup) {
		this.bmiGroup = bmiGroup;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
