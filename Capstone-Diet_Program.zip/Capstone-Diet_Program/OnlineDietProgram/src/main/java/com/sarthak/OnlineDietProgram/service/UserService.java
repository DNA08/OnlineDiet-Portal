package com.sarthak.OnlineDietProgram.service;

import java.util.List;

import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarthak.OnlineDietProgram.entity.PendingRequestEntity;
import com.sarthak.OnlineDietProgram.entity.UserCredEntity;
import com.sarthak.OnlineDietProgram.entity.UserEntity;
import com.sarthak.OnlineDietProgram.repository.NewUserRepo;
import com.sarthak.OnlineDietProgram.repository.PendingRepo;
import com.sarthak.OnlineDietProgram.repository.UserCredRepo;

@Service
public class UserService {

	@Autowired
	NewUserRepo newUserRepo;

	@Autowired
	PendingRepo pendingRepo;
	
	@Autowired
	UserCredRepo userCredRepo;
	
	@Autowired
	MailService mailService;
	
	public void adduser(PendingRequestEntity userEntity) {
		pendingRepo.save(userEntity);
		System.out.println("Adding user Successfully in Pending requests");
	}

	public List<UserEntity> getAllUserDetail() {
		return newUserRepo.findAll();
	}

	public PendingRequestEntity getPendingUserByMail(String mail) {
		System.out.println(pendingRepo.findByMail(mail).getAddress());
		return pendingRepo.findByMail(mail);
	}
	
	public UserEntity getUserByMail(String mail) {
		System.out.println(pendingRepo.findByMail(mail));
		return newUserRepo.findByMail(mail);
	}

	public List<PendingRequestEntity> getAllPendingRequest() {
		System.out.println("Giving all Pending requests");
		return pendingRepo.findAll();
	}

	public void deleteRequest(PendingRequestEntity input) {
		System.out.println("In backend Rejection User");
		String email = input.getMail();
		pendingRepo.deleteById(email);
		mailService.sendNotification(email, "User Request Rejected", "Your request has been declined due to some reasons.");
		System.out.println("In backend: Successfully Rejected");
	}

	public void acceptUser(PendingRequestEntity input) {
		System.out.println("In backend Accepting User");
		UserCredEntity userCredEntity = new UserCredEntity();
		double bmi=0.0;
		String mail = input.getMail();
		UserEntity userEntity = new UserEntity();
		
		bmi = input.getWeight()/Math.pow(input.getHeight(), 2);
		bmi = bmi*10000;
		userEntity.setMail(mail);
		userEntity.setAddress(input.getAddress());
		userEntity.setAge(input.getAge());
		userEntity.setCity(input.getCity());
		userEntity.setDiet(input.getDiet());
		userEntity.setGender(input.getGender());
		userEntity.setPhone(input.getPhone());
		userEntity.setPinCode(input.getPinCode());
		userEntity.setState(input.getState());
		userEntity.setCountry(input.getCountry());
		userEntity.setFirstName(input.getFirstName());
		userEntity.setLastName(input.getLastName());
		userEntity.setHeight(input.getHeight());
		userEntity.setWeight(input.getWeight());
		userEntity.setBmi(bmi);
		
		newUserRepo.save(userEntity);
		if(bmi>25.0)
			userCredEntity.setBmiGroup("above");
		else
			userCredEntity.setBmiGroup("below");
		userCredEntity.setMail(mail);
		userCredEntity.setPassword(mail+"_DietProgram");
		userCredEntity.setType("User");
		
		userCredRepo.save(userCredEntity);
		pendingRepo.delete(input);
		mailService.sendNotification(mail, "User Request Accepted", "Your request has been approved. Your Login user name is your mail id and password is="+ mail+"_DietProgram");
		System.out.println("In backend SUCCESSFULLY Added User");
	}

	public void deleteUser(UserEntity user) {
		
		UserCredEntity userOne = userCredRepo.findByMail(user.getMail());
		userCredRepo.delete(userOne);
		newUserRepo.delete(user);
	}

	public void setUserType(UserEntity user, String userType) {
		UserCredEntity userCred = userCredRepo.findByMail(user.getMail());
		System.out.println("User mail going to change the type is="+user.getMail());
		userCred.setType(userType);
		userCredRepo.save(userCred);
	}

	public String getUserType(String mail) {
		System.out.println("User mail going to change the type is="+ mail);
		return userCredRepo.findByMail(mail).getType();
	}
	
	public UserCredEntity getUserDetail(String email) {
		System.out.println("Mail is ="+email);
		return userCredRepo.findByMail(email);
	}
}
