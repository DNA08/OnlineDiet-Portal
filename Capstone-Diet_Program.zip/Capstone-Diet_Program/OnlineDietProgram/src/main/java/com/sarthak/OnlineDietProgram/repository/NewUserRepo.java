package com.sarthak.OnlineDietProgram.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sarthak.OnlineDietProgram.entity.PendingRequestEntity;
import com.sarthak.OnlineDietProgram.entity.UserEntity;

@Repository
public interface NewUserRepo extends JpaRepository<UserEntity, String> {
	UserEntity findByMail(String mail);

}
