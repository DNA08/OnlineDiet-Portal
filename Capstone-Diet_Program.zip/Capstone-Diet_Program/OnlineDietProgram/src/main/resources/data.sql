INSERT INTO USER_CRED (MAIL,PASSWORD,TYPE,BMI_GROUP) values ('sarthak@gmail.com','wipro@123','Admin','NA');
